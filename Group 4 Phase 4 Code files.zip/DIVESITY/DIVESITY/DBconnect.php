<!DOCTYPE  >
<html>
<head>
<title> JR </title>

</head>

<body>

<?php
//connecting to the database
$servername = "localhost";
$username = "root";
$password = "";
$DBname = "diversey";

$mysqli=new mysqli("localhost", "root", "");
//$conn=  mysqli_connect("localhost", "root", "");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}else {
			  }
return $mysqli;
?>

</body > 
</html>