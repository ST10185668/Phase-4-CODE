

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Validated Login Form</title>
	<link rel="stylesheet" href="logIn.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
</head>
<body>
	<div class="container">
        <p class="form__text1">
            <a href="index.html"><i class='bx bx-arrow-back'></i></a>
        </p>
        
		<h1 class="label">User Register</h1>
		<form class="login_form"  method="post" onsubmit="return validated()"  >
			<div class="font font2">Full Name</div>
			<input type="text" name="Name" id="Name">

            <div class="font font2">Phone Number</div>
			<input type="number" name="PhoneNumber" id="PhoneNumber">

            <div class="font">Email</div>
			<input autocomplete="off" type="text" name="email" id="email">
			<div id="email_error">Please fill up your Email or Phone</div>

            <div class="font font2">Password</div>
			<input type="password" name="password" id="password">

			<div id="pass_error">Please fill up your Password</div>
			<button type="submit">Login</button>
			<p class="form__text">
                <a class="form__link" href="./" id="linkLogin">Already have an account? Sign in</a>
            </p>
		</form>
	</div>	
	<script src="valid.js"></script>

    <?php
if( isset($_POST['Name']) )
{ //geting the input from the user
	$Fname = $_POST['Name'];
	 $Pword = $_POST['password'];
     $Email= $_POST['email'];
     $Pnumbers= $_POST['PhoneNumber'];
     $N_orders=0;
     $Address= 'ssssss';
	$hashed_Pword = password_hash($Pword,PASSWORD_DEFAULT);

	include "DBConnect.php";// connecting to the database
	 //the sql needed to store values in the table
	$InsertSql ="INSERT INTO diversey.customer(name,email,phone_number,password,num_of_orders,address) VALUES('$Fname','$Email',0693065526,'$Pword' ,0,'$Address');";
   //$sql=mysqli_query($mysqli,$InsertSql);
	//$sql=mysqli_query($mysqli,$InsertSql);	
    
    $checkValueExists = "SELECT id FROM diversey.customer 
							WHERE 
							customer.email='$Email'"; 
	//$sql=mysqli_query($mysqli,$InsertSql);						
	$result = mysqli_query($mysqli,$checkValueExists);
// verifying and checcking if the information entered does not already exist in the table
	if($result){
		echo '<script>alert("This User Already Exists")</script>';// if it does
	}
	else{
		
		if($mysqli->query($InsertSql) == TRUE){	
		echo '<script>alert("Your Account has been created!!!")</script>';	// if it does not exist
		}
		else
		{
		echo "Error: " .$InsertSql. "<br>" .$mysqli->error;// error if something went wrong when inserting into table
		}
		
	}						
}
?>
</body>
</html>



