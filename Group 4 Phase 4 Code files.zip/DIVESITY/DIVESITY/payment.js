document.getElementById('checkout').addEventListener('click', function() {
  // Check if the user is logged in
  var isLoggedIn = localStorage.getItem('isLoggedIn');
  if (isLoggedIn !== 'true') {
    alert('Please log in before proceeding with payment.');
    window.location.href = 'login.html'; // Redirect to login page
  } else {
    // User is logged in, proceed with payment
    alert('Procced with payment');
    window.location.href = 'checkout.html'; // Redirect to login page
   
  }
});