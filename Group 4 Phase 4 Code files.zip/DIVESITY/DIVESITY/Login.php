<?php
 $is_invalid= false ;
  
 IF($_SERVER["REQUEST_METHOD"]==="POST" ){
	 $mysqli= require "DBconnect.php";//connecting to the db page
	 $sql=sprintf("SELECT * FROM diversey.customer
	              Where customer.email='%s'",
				  $mysqli->real_escape_string($_POST["email"]));
				  
	 $result=$mysqli->query($sql);
	 $user=$result->fetch_assoc();
	 if($user){
        

		if($_POST["password"]==$user["password"]){
			header("Location:index.php");
			  exit;
		}else{
			echo '<script>alert("Wrong login details")</script>';
			

		}
		
		
	 }
	 $is_ivalid= true;
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Validated Login Form</title>
	<link rel="stylesheet" href="logIn.css">
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>

</head>
<body>
           
			
			<?php if($is_invalid): ?>
			<em>Invalid login</em>
			<?php endif;?>
			
	<div class="container">
		<p class="form__text1">
            <a href="index.html"><i class='bx bx-arrow-back'></i></a>
        </p>
		<h1 class="label">User Login</h1>
		<form method="post" class="login_form"  onsubmit="return validated()">
			<div class="font">Email or Phone</div>
			<input autocomplete="off" type="text" name="email" id="email">
			<?=htmlspecialchars($_POST["email"]??"")?>
			<div id="email_error">Please fill up your Email or Phone</div>
			<div class="font font2">Password</div>
			<input type="password" name="password" id="password">
			<div id="pass_error">Please fill up your Password</div>
			<button >Login</button>
		</form>

		<p class="form__text">
			<a class="form__link" href="register.php" id="linkLogin">Already have an account? Sign in</a>
		</p>
	</div>	
	<script src="valid.js"></script>
	<script src="login.js"></script>
</body>
</html>