document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('editModal');
    const addModal = document.getElementById('addModal');
    const addProductBtn = document.getElementById('addProductBtn');
    const closeAddModal = document.querySelector('#addModal .close');
    const closeEditModal = document.querySelector('#editModal .close');
    let currentProductBox = null;

    document.querySelectorAll('.more').forEach(function(moreButton) {
        moreButton.addEventListener('click', function() {
            const menu = moreButton.nextElementSibling;
            menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
        });
    });

    document.addEventListener('click', function(event) {
        if (!event.target.matches('.more')) {
            document.querySelectorAll('.menu').forEach(function(menu) {
                menu.style.display = 'none';
            });
        }
    });

    addProductBtn.addEventListener('click', () => {
        addModal.style.display = 'block';
    });

    closeAddModal.addEventListener('click', () => {
        addModal.style.display = 'none';
    });

    closeEditModal.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === addModal) {
            addModal.style.display = 'none';
        }
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Delete row when delete icon is clicked
    document.querySelectorAll('.remove').forEach(deleteIcon => {
        deleteIcon.addEventListener("click", function() {
            const productBox = this.closest('.product-box');
            productBox.remove();
            // Optionally send an AJAX request to delete the item from the database
        });
    });

    // Handle product edit
    document.querySelectorAll('.edit').forEach(editIcon => {
        editIcon.addEventListener("click", function() {
            currentProductBox = this.closest('.product-box');
            const name = currentProductBox.querySelector('h4').textContent;
            const description = currentProductBox.querySelector('p').textContent;
            const price = currentProductBox.querySelector('.price').textContent.replace('R', '');
            const image = currentProductBox.querySelector('img').src;

            document.getElementById('editName').value = name;
            document.getElementById('editDescription').value = description;
            document.getElementById('editPrice').value = price;
            document.getElementById('editImage').value = image;

            modal.style.display = 'block';
        });
    });

    // Save edited product
    document.getElementById('editForm').addEventListener('submit', function(event) {
        event.preventDefault();

        const name = document.getElementById('editName').value;
        const description = document.getElementById('editDescription').value;
        const price = document.getElementById('editPrice').value;
        const image = document.getElementById('editImage').value;

        currentProductBox.querySelector('h4').textContent = name;
        currentProductBox.querySelector('p').textContent = description;
        currentProductBox.querySelector('.price').textContent = 'R' + price;
        currentProductBox.querySelector('img').src = image;

        modal.style.display = 'none';

        // Optionally send an AJAX request to update the item in the database
    });
});
