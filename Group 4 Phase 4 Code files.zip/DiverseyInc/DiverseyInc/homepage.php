<?php
session_start();
include("connect.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">
    <link rel= "stylesheet" href= "https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css" >
    <link rel="stylesheet" href="styles.css">
    <title>HomePage | Diversey Inc</title>
</head>

<body>

    <input type="checkbox" id="nav-toggle">
    <div class="sidebar">
        <!--<div class="side-logo">
            <img src="footer logo.png" alt="Diversey logo" width="345px" height="85px">
        </div>-->

        <div class="sideMenu">
            <ul>
                <li>
                    <a href="homepage.php" class="active"><span class="las la-igloo"></span>
                    <span>Dashboard</span></a>
                </li>
    
                <li>
                    <a href="customer.php"><span class="las la-users"></span>
                    <span>Customers</span></a>
                </li>
    
                <li>
                    <a href="products.php"><span class="las la-list"></span>
                    <span>Products</span></a>
                </li>
    
                <li>
                    <a href="order.php"><span class="las la-shopping-bag"></span>
                    <span>Orders</span></a>
                </li>
    
                <li>
                    <a href="messages.php"><span class="las la-envelope"></span>
                    <span>Messages</span></a>
                </li>
    
                <li>
                    <a href="admin.php"><span class="las la-user-circle"></span>
                    <span>Account</span></a>
                 </li>
                 
            </ul>
            <a href="logout.php"><span class="las la-sign-out-alt"></span>Logout</a>
        </div>
    </div>

    <div class="logo-2nd">
        <img src="_images/images.png" alt="second Company logo">
    </div>

    <div class="content">
        <header>
            <div class="logo">
                <img src="_images/header logo.jpeg" alt="Diversey logo" width="345px" height="78px">
            </div>

            <h2>
                <label for="nav-toggle">
                    <span class="las la-bars"></span>
                </label>

                Dashboard
            </h2>

            <div class="search-wrapper">
                <span class="las la-search"></span>
                <input type="search" placeholder="Search here" />
            </div>
            
            <div class="user-wrapper">
                <img src="_images/img.png" width="40px" height="40px" alt="Admin profile">
                <div>
                    <h4><?php 
                            if(isset($_SESSION['email'])){
                             $email=$_SESSION['email'];
                             $query=mysqli_query($conn, "SELECT admin.* FROM `admin` WHERE admin.email='$email'");
                            while($row=mysqli_fetch_array($query)){
                            echo $row['admin_name'];
                            }
                        }
                    ?></h4>
                    <small>Company Admin</small>
                </div>
            </div>
        </header>
    </div>

    <main>
        <div class="cards">
            <div class="card-single">
                <div>
                    <h1>54</h1>
                    <span>Customers</span>
                </div>
                <div>
                    <span class="las la-users"></span>
                </div>
            </div>

            <div class="card-single">
                <div>
                    <h1>45</h1>
                    <span>Products</span>
                </div>
                <div>
                    <span class="las la-clipboard-list"></span>
                </div>
            </div>

            <div class="card-single">
                <div>
                    <h1>14</h1>
                    <span>Orders</span>
                </div>
                <div>
                    <span class="las la-shopping-bag"></span>
                </div>
            </div>
        </div> 
        
        <div class="recent-grid">
            <div class="products">
                <div class="card">
                    <div class="card-header">
                        <h3>New Products</h3>

                        <a href="products.php"><button>See all<span class="las la-arrow-right">                           
                        </span></button></a>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table width="100%">
                                <thead>
                                    <tr>
                                        <td>Product Name</td>
                                        <td>Description</td>
                                        <td>Option</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <strong>Soap</strong>
                                            <img src="_images/ARGOSY-WHITE-BATH-SOUP.png" width="200px" height="100px" alt="">
                                        </td>
                                        <td><strong>Argosy</strong> is a top quality, individually wrapped toilet soap which
                                            carries the SABS 237 "<strong>Toilet Soap</strong>" mark.
                                            Argosy is ideal for use in hotels, boarding houses, restaurants and
                                            all major institutions and can be used anywhere if a top quality toilet
                                            soap is required.</td>
                                        <td>
                                            <div class="edit">
                                                <span class="las la-edit"></span>
                                            </div>
                                            <div class="remove">
                                                <span class="las la-trash"></span>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>Liquid</strong>
                                            <img src="_images/SUMABRITE-DW-GEL-20X500ML-500ml@1x.png" width="200px" alt="">
                                        </td>
                                        <td><strong>Sumabrite™ Concentrated Dishwashing Liquid Gel 500ml</strong> is a concentrated dishwash liquid gel that is effective in removing all grease and food stains from crockery, utensils and cutlery.</td>
                                        <td>
                                            <div class="edit">
                                                <span class="las la-edit"></span>
                                            </div>
                                            <div class="remove">
                                                <span class="las la-trash"></span>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>Wipes</strong>
                                            <img src="_images/-product-051809.jpg" width="200px" height="120px" alt="">
                                        </td>
                                        <td><strong>Diversey Oxivir Excel combined Cleaner & Disinfectant</strong>, powered by AHP Technology, provides you with the best alternative to your traditional disinfectants by delivering full virucidal efficacy in just 30 seconds in dirty conditions, while being very gentle to surfaces and with the lowest risk to your staff and customer.</td>
                                        <td>
                                            <div class="edit">
                                                <span class="las la-edit"></span>
                                            </div>
                                            <div class="remove">
                                                <span class="las la-trash"></span>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>                        
                    </div>
                </div>
            </div>

            <div class="customers">
                <div class="card">
                    <div class="card-header">
                        <h3>New Customers</h3>

                        <a href="customer.php"><button>See all<span class="las la-arrow-right">                           
                        </span></button></a>
                    </div>

                    <div class="card-body">
                        <div class="customer">
                            <div class="info">
                                <img src="_images/img.png" width="40px" height="40px" alt="User profile">
                                <div>
                                    <h4>Jabulani S. Dhludhlu</h4>
                                    <small>Front-end Developer</small>
                                </div>
                            </div>
                            <div class="contact">
                                <span class="las la-user-circle"></span>
                                <span class="las la-envelope"></span>
                                <span class="las la-phone"></span>
                            </div>
                        </div>

                        <div class="customer">
                            <div class="info">
                                <img src="_images/img.png" width="40px" height="40px" alt="User profile">
                                <div>
                                    <h4>Jabulani S. Dhludhlu</h4>
                                    <small>Front-end Developer</small>
                                </div>
                            </div>
                            <div class="contact">
                                <span class="las la-user-circle"></span>
                                <span class="las la-envelope"></span>
                                <span class="las la-phone"></span>
                            </div>
                        </div>

                        <div class="customer">
                            <div class="info">
                                <img src="_images/img.png" width="40px" height="40px" alt="User profile">
                                <div>
                                    <h4>Jabulani S. Dhludhlu</h4>
                                    <small>Front-end Developer</small>
                                </div>
                            </div>
                            <div class="contact">
                                <span class="las la-user-circle"></span>
                                <span class="las la-envelope"></span>
                                <span class="las la-phone"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    
    <script src="scripts.js"></script>
    
</body>
</html>
       