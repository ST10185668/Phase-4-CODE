<?php
session_start();
include("connect.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">
    <link rel= "stylesheet" href= "https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css" >
    <link rel="stylesheet" href="styles.css">
    <title>Orders | Diversey Inc</title>
</head>

<body>

    <input type="checkbox" id="nav-toggle">
    <div class="sidebar">
        <!--<div class="side-logo">
            <img src="footer logo.png" alt="Diversey logo" width="345px" height="85px">
        </div>-->

        <div class="sideMenu">
            <ul>
                <li>
                    <a href="homepage.php"><span class="las la-igloo"></span>
                    <span>Dashboard</span></a>
                </li>
    
                <li>
                    <a href="customer.php"><span class="las la-users"></span>
                    <span>Customers</span></a>
                </li>
    
                <li>
                    <a href="products.php"><span class="las la-list"></span>
                    <span>Products</span></a>
                </li>
    
                <li>
                    <a href="order.php"><span class="las la-shopping-bag"></span>
                    <span>Orders</span></a>
                </li>
    
                <li>
                    <a href="messages.php"><span class="las la-envelope"></span>
                    <span>Messages</span></a>
                </li>
    
                <li>
                    <a href="admin.php" class="active"><span class="las la-user-circle"></span>
                    <span>Account</span></a>
                 </li>
            </ul>
            <a href="logout.php"><span class="las la-sign-out-alt"></span>Logout</a>
        </div>
    </div>

    <div class="logo-2nd">
        <img src="_images/images.png" alt="second Company logo">
    </div>

    <div class="content">
        <header>
            <div class="logo">
                <img src="_images/header logo.jpeg" alt="Diversey logo" width="345px" height="78px">
            </div>

            <h2>
                <label for="nav-toggle">
                    <span class="las la-bars"></span>
                </label>

                Admin
            </h2>

            <div class="search-wrapper">
                <span class="las la-search"></span>
                <input type="search" placeholder="Search here" />
            </div>
            
            <div class="user-wrapper">
                <img src="_images/img.png" width="40px" height="40px" alt="Admin profile">
                <div>
                <h4><?php 
                            if(isset($_SESSION['email'])){
                             $email=$_SESSION['email'];
                             $query=mysqli_query($conn, "SELECT admin.* FROM `admin` WHERE admin.email='$email'");
                            while($row=mysqli_fetch_array($query)){
                            echo $row['admin_name'];
                            }
                        }
                    ?></h4>
                    <small>Company Admin</small>
                </div>
            </div>
        </header>
    </div>

    <main>
        
    </main>
        
</body>
</html>